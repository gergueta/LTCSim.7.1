// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#ifndef STRICT
#define STRICT 1
#endif

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <stdlib.h>
#include <direct.h>
#include <io.h>
#include <share.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <tcl.h>
#include <tk.h>
//#include "tclDecls.h"
//#include "tclInt.h"
//#include "tclIntDecls.h"
//#include "tclPlatDecls.h"
//#include "tk.h"
//#include "tkDecls.h"
//#include "tkIntXlibDecls.h"
//#include "tkPlatDecls.h"
